from setuptools import setup, find_packages

setup(name='joint_extr', version='1.0', packages=find_packages())